转码手机上的酷我音乐

```
# Install dependencies
npm install
# Run the app
npm start
```

---
tips:
    1.当前为第一版，可能没有下一版了
    2.虽然项目中依赖了sqlite3，但是没有使用
    3.当前版本会把歌曲文件直接转码，源文件删除